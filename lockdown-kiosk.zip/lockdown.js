// Disable right-click
document.addEventListener('contextmenu', event => event.preventDefault());

// Disable certain keys
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey) {
    e.preventDefault();
  }
});